import sqlite3

def add_book(title, author, isbn, genre, status):
    conn = sqlite3.connect("library.db")
    cur = conn.cursor()

    cur.execute("INSERT INTO books VALUES(NULL,?,?,?,?,?)",
                (title, author, isbn, genre, status))

    conn.commit()
    conn.close()


def view_books():
    conn = sqlite3.connect("library.db")
    cur = conn.cursor()

    cur.execute("SELECT title,author,isbn,genre,status FROM books")
    rows = cur.fetchall()

    conn.close()
    return rows


def delete_book(isbn):
    conn = sqlite3.connect("library.db")
    cur = conn.cursor()

    cur.execute("DELETE FROM books WHERE isbn=?", (isbn,))

    conn.commit()
    conn.close()

def update_book(title, author, isbn, genre, status):
    conn = sqlite3.connect("library.db")
    cur = conn.cursor()

    cur.execute("""
    UPDATE members
    SET title=? author=? genre=? status=? 
    WHERE isbn=?
    """,(title, author, isbn, genre, status))

    conn.commit()
    conn.close()

