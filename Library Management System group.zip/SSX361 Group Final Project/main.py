from tkinter import *
from tkinter import ttk
from db import create_tables
from books import add_book
from books import view_books
from books import delete_book
from books import update_book
from members import add_member
from members import view_members
from members import delete_member
from members import update_member

# Create DB
create_tables()

root = Tk()
root.title("BC Book Library System")
root.geometry("600x500")

# ================= BOOKS WINDOW =================
def open_books():
    win = Toplevel()
    win.title("Books Management")

    title = StringVar()
    author = StringVar()
    isbn = StringVar()
    genre = StringVar()
    status = StringVar()

    Label(win, text="Title").grid(row=0, column=0)
    Entry(win, textvariable=title).grid(row=0, column=1)

    Label(win, text="Author").grid(row=1, column=0)
    Entry(win, textvariable=author).grid(row=1, column=1)

    Label(win, text="ISBN").grid(row=2, column=0)
    Entry(win, textvariable=isbn).grid(row=2, column=1)

    Label(win, text="Genre").grid(row=3, column=0)
    Entry(win, textvariable=genre).grid(row=3, column=1)

    Label(win, text="Status").grid(row=4, column=0)
    Entry(win, textvariable=status).grid(row=4, column=1)
    # Treeview
    tree = ttk.Treeview(win, columns=("Title", "Author", "ISBN", "Genre", "Status"), show="headings")
    for col in ("Title", "Author", "ISBN", "Genre", "Status"):
       tree.heading(col, text=col)
    tree.grid(row=0, column=2, rowspan=7, padx=10)

    def view():
       tree.delete(*tree.get_children())
       for row in view_books():
          tree.insert("", END, values=row)

    def add():
       add_book(title.get(), author.get(), isbn.get(), genre.get(), status.get())
       add()

    def delete():
       selected = tree.focus()
       values = tree.item(selected, "values")
       delete_book(values[1])
       view()

    def update():
        selected = tree.focus()
        if not selected:
            return

        values = tree.item(selected, "values")
        update_book(title.get(), author.get(), values[2], genre.get(), status.get())
        view()

    Button(win, text="Add", command=add).grid(row=5, column=0)
    Button(win, text="View", command=view).grid(row=5, column=1)
    Button(win, text="Delete", command=delete).grid(row=6, column=0)
    Button(win, text="Update", command=update).grid(row=6, column=1)

# ================= MEMBERS WINDOW =================

def open_members():
    win = Toplevel()
    win.title("Members Management")

    name = StringVar()
    member_id = StringVar()
    contact = StringVar()
    m_type = StringVar()

    Label(win, text="Name").grid(row=0, column=0)
    Entry(win, textvariable=name).grid(row=0, column=1)

    Label(win, text="Member ID").grid(row=1, column=0)
    Entry(win, textvariable=member_id).grid(row=1, column=1)

    Label(win, text="Contact").grid(row=2, column=0)
    Entry(win, textvariable=contact).grid(row=2, column=1)

    Label(win, text="Type").grid(row=3, column=0)
    Entry(win, textvariable=m_type).grid(row=3, column=1)

    tree = ttk.Treeview(win, columns=("Name", "ID", "Contact", "Type"), show="headings")
    for col in ("Name", "ID", "Contact", "Type"):
       tree.heading(col, text=col)
    tree.grid(row=0, column=2, rowspan=6)

    def add():
        add_member(name.get(), member_id.get(), contact.get(), m_type.get())
        view()


    def view():
       tree.delete(*tree.get_children())
       for row in view_members():
        tree.insert("", END, values=row)

    def delete():
        selected = tree.focus()
        if not selected:
            return

        values = tree.item(selected, "values")
        delete_member(values[1])
        view()

    def update():
        selected = tree.focus()
        if not selected:
            return

        values = tree.item(selected, "values")
        update_member(name.get(), values[1], contact.get(), m_type.get())
        view()

    Button(win, text="Add", command=add).grid(row=5, column=0)
    Button(win, text="View", command=view).grid(row=5, column=1)
    Button(win, text="Delete", command=delete).grid(row=6, column=0)
    Button(win, text="Update", command=update).grid(row=6, column=1)

#---------MAIN WINDOWS------------------

# Title
Label(
    root,
    text="📖 BCBook Library System",
    font=("Arial", 18, "bold")
).pack(pady=30)

# Center frame
main_frame = Frame(root)
main_frame.pack(expand=True)

# Buttons
btn_books = Button(
    main_frame,
    text="Books Management",
    command=open_books,
    font=("Arial", 12, "bold"),
    bg="#4CAF50",
    fg="white",
    width=20,
    height=2,
    relief="raised",
    bd=3
)
btn_books.grid(row=0, column=0, padx=20, pady=10)

btn_members = Button(
    main_frame,
    text="Members Management",
    command=open_members,
    font=("Arial", 12, "bold"),
    bg="#2196F3",
    fg="white",
    width=20,
    height=2,
    relief="raised",
    bd=3
)
btn_members.grid(row=0, column=1, padx=20, pady=10)
root.mainloop()


