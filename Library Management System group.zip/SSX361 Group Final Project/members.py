import sqlite3

def add_member(name, member_id, contact, m_type):
    conn = sqlite3.connect("library.db")
    cur = conn.cursor()

    cur.execute("INSERT INTO members VALUES(NULL,?,?,?,?)",
                (name, member_id, contact, m_type))

    conn.commit()
    conn.close()


def view_members():
    conn = sqlite3.connect("library.db")
    cur = conn.cursor()

    cur.execute("SELECT name,member_id,contact,m_type FROM members")
    rows = cur.fetchall()

    conn.close()
    return rows


def delete_member(member_id):
    conn = sqlite3.connect("library.db")
    cur = conn.cursor()

    cur.execute("DELETE FROM members WHERE member_id=?", (member_id,))

    conn.commit()
    conn.close()

def update_member(name, member_id, contact, m_type):
    conn = sqlite3.connect("library.db")
    cur = conn.cursor()

    cur.execute("""
    UPDATE members
    SET name=? contact=? m_type=? 
    WHERE member_id=?
    """,(name, member_id, contact, m_type))

    conn.commit()
    conn.close()
